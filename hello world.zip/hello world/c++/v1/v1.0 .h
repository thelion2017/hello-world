#include 

int main()
{
    std::cout << "Hello, world!
";
    return 0;
}
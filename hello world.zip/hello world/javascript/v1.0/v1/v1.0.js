alert ("hello world!");
document.write('Hello, world!');
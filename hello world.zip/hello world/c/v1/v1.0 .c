#include 

int main(void)
{
    puts("Hello, world!");
}